Una pequeña aplicación de prueba que simula una aplicación de videoconferencias.
