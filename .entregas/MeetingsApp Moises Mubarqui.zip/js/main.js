/* Meetings app */

/* Funciones que debería tener:
    * [Listo] Agregar participante
    * [Listo] Prender/Apagar cámara
    * [Listo] Prender/Apagar micrófono
    * [Listo] Subir/Bajar volumen
    * [Listo] Listar participantes
  */

let participantes = [];
let camara = false;
let microfono = false;
let volumen = 50;

function agregar_participante() {
    let nombre = prompt("Hola, ¿Cuál es tu nombre?");
    participantes.push(nombre);
    console.log(`Bienvenido/a a la reunión ${nombre}.`);
}

function listar_participantes() {
    console.log("En la reunión están:")
    for (let i = 0; i < participantes.length; i += 1) {
        console.log(participantes[i]);
    }
}

function prender_camara() {
    camara = true;
    console.log(`Cámara prendida: ${camara}`);
    alert(`Cámara prendida: ${camara}`);
}

function apagar_camara() {
    camara = false;
    console.log(`Cámara prendida: ${camara}`);
    alert(`Cámara prendida: ${camara}`);
}

function toggle_camara() {
    if (camara == true) {
        apagar_camara();
    } else {
        prender_camara();
    }
}


function prender_microfono() {
    microfono = true;
    console.log(`Micrófono prendido: ${microfono}`);
    alert(`Micrófono prendido: ${microfono}`);
}

function apagar_microfono() {
    microfono = false;
    console.log(`Micrófono prendido: ${microfono}`);
    alert(`Micrófono prendido: ${microfono}`);
}

function toggle_microfono() {
    if (microfono == true) {
        apagar_microfono();
    } else {
        prender_microfono();
    }
}

function subir_volumen() {
    volumen = volumen + 10;
    if (volumen >= 100) {
        console.log("Volumen máximo");
        volumen = 100;
    }
    console.log(`El volumen está al ${volumen}`);
    alert(`El volumen está al ${volumen}`);
}

function bajar_volumen() {
    volumen = volumen - 10;
    if (volumen <= 0) {
        console.log("Volumen apagado");
        volumen = 0;
    }
    console.log(`El volumen está al ${volumen}`);
    alert(`El volumen está al ${volumen}`);
}

agregar_participante();
let go_on = true;

while (go_on) {
    let opcion1;
    let opcion2;
    if (camara == true) {
        opcion1 = "Apagar cámara";
    } else {
        opcion1 = "Prender cámara";
    }

    if (microfono == true) {
        opcion2 = "Apagar micrófono";
    } else {
        opcion2 = "Prender micrófono";
    }

    let decision = prompt(`¿Qué deseas hacer? 
Opciones:
0: Agregar participante
1: ${opcion1}
2: ${opcion2}
+: Subir volumen
-: Bajar volumen`)
    switch (decision) {
        case "0":
            agregar_participante();
            listar_participantes();
            break
        case "1":
            toggle_camara();
            break;
        case "2":
            toggle_microfono();
            break;
        case "+":
            subir_volumen();
            break;
        case "-":
            bajar_volumen();
            break;
        default:
            go_on = false;
            break;
    }
}